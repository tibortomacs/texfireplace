@echo off
chcp 65001

setlocal enableextensions
md "%~dp0temp"

:: Python

if exist "%~dp0python" goto pythonend
if exist "%~dp0pygments" (
xcopy /E /I "%~dp0pygments" "%~dp0backup\pygments"
rename "%~dp0pygments" python
goto pythonend
)
curl -L -o python.html --output-dir "%~dp0temp" https://docs.python.org/
if not exist "%~dp0temp\python.html" goto downloadpython
for /F "usebackq tokens=5,6" %%i in ("%~dp0temp\python.html") do if "%%j"=="Documentation</title><meta" set "pythonver=%%i"
set "pythonver=%pythonver:<= %"
set "pythonver=%pythonver:>= %"
for /F "tokens=3" %%i in ('echo %pythonver%') do set "pythonver=%%i"
curl -L -o python.zip --output-dir "%~dp0temp" https://www.python.org/ftp/python/%pythonver%/python-%pythonver%-embed-amd64.zip
:downloadpython
if not exist "%~dp0temp\python.zip" curl -L -o python.zip https://www.python.org/ftp/python/3.12.2/python-3.12.2-embed-amd64.zip
md "%~dp0python"
tar -xf "%~dp0temp\python.zip" -C "%~dp0python"
curl -L -o get-pip.py --output-dir "%~dp0temp" https://bootstrap.pypa.io/get-pip.py
rename "%~dp0python\*._pth" "*.pth"
"%~dp0python\python.exe" "%~dp0temp\get-pip.py"
:pythonend

:: latexminted

"%~dp0python\python.exe" -m pip install latexminted

:: Strawberry Perl

if exist "%~dp0perl" goto perlend
if exist "%~dp0tlperl" move /Y "%~dp0tlperl" "%~dp0backup\tlperl"
curl -L -o strawberryperl.html --output-dir "%~dp0temp" https://strawberryperl.com/releases.html
for /F "tokens=1 delims=" %%a in ('findstr "portable.zip" "%~dp0temp\strawberryperl.html"') do (
set "perlurl=%%a" 
goto perlnext
)
:perlnext
for /F tokens^=2^ delims^=^" %%a in ('echo "%perlurl%"') do set "perlurl=%%a"
curl -L -o perl.zip --output-dir "%~dp0temp" %perlurl%
md "%~dp0temp\perl"
tar -xf "%~dp0temp\perl.zip" -C "%~dp0temp\perl"
move /Y "%~dp0temp\perl\perl" "%~dp0perl"
:perlend

:: Removing old files/folders

rmdir /S /Q "%~dp0temp"
rmdir /S /Q "%~dp0backup"
rmdir /S /Q "%~dp0colorschemes"
rmdir /S /Q "%~dp0config"
rmdir /S /Q "%~dp0langs"
rmdir /S /Q "%~dp0txsconfig"
del "%~dp0restore.exe"
del "%~dp0tfptexstudio.exe"
del "%~dp0uninstall.exe"
del "%~dp0readme.txt"
del "%~dp0texfireplace.exe"
rmdir /S /Q "%appdata%\Microsoft\Windows\Start Menu\TeXfireplace"
rmdir /S /Q "%appdata%\Microsoft\Windows\Start Menu\Programs\TeXfireplace"
del "%appdata%\Microsoft\Windows\Start Menu\TeXfireplace.lnk"
del "%userprofile%\Desktop\TeXfireplace.lnk"
reg delete "HKCU\Software\Classes\.tex" /f
reg delete "HKCU\Software\Classes\texfile" /f

:: miktex-console.vbs

(
echo Set oShell = CreateObject("Wscript.Shell"^)
echo Set FSO = CreateObject("Scripting.FileSystemObject"^)
echo Set objFile = FSO.GetFile(Wscript.ScriptFullName^)
echo TeXfireplaceFolder = FSO.GetParentFolderName(objFile^)
echo strArgs = "cmd /c set path=" + TeXfireplaceFolder + "\texmfs\install\miktex\bin\x64;%%path%% & call miktex-console.exe"
echo oShell.Run strArgs, 0, false
) > "%~dp0miktex-console.vbs"

:: texstudio.vbs

(
echo Set oShell = CreateObject("Wscript.Shell"^)
echo Set FSO = CreateObject("Scripting.FileSystemObject"^)
echo Set objFile = FSO.GetFile(Wscript.ScriptFullName^)
echo TeXfireplaceFolder = FSO.GetParentFolderName(objFile^)
echo strArgs = "cmd /c set path="
echo strArgs = strArgs + TeXfireplaceFolder + "\texmfs\install\miktex\bin\x64;"
echo strArgs = strArgs + TeXfireplaceFolder + "\perl\bin;"
echo strArgs = strArgs + TeXfireplaceFolder + "\python;" + TeXfireplaceFolder + "\python\Scripts;"
echo strArgs = strArgs + "%%path%% "
echo strArgs = strArgs + "& call """ + TeXfireplaceFolder + "\texstudio\texstudio.exe"""
echo If WScript.Arguments.Count ^> 0 Then strArgs = strArgs + " """ + WScript.Arguments.Item(0^) + """"
echo oShell.Run strArgs, 0, false
) > "%~dp0texstudio.vbs"

:: update.bat

(
echo @echo off
echo chcp 65001^> nul
echo title Updating TeXfireplace
echo set /p ^< nul = "Press any key to update TeXfireplace . . ."
echo pause ^> nul
echo cls
echo echo ---------------
echo echo Updating MiKTeX
echo echo ---------------
echo echo.
echo "%%~dp0texmfs\install\miktex\bin\x64\miktex" packages update
echo echo.
echo echo -----------------------------
echo echo Updating Pygments/latexminted
echo echo -----------------------------
echo echo.
echo if exist "%%~dp0python\Scripts\pygmentize.exe" "%%~dp0python\python.exe" -m pip install --upgrade Pygments
echo if exist "%%~dp0python\Scripts\latexminted.exe" "%%~dp0python\python.exe" -m pip install --upgrade latexminted
echo echo.
echo echo ------------------
echo echo Updating TeXstudio
echo echo ------------------
echo echo.
echo set "status=completed"
echo curl -L -o texstudio.html https://www.texstudio.org/
echo for /f "tokens=1 delims=" %%%%a in ('findstr "win-portable-qt6.zip" "%%~dp0texstudio.html"'^) do set "txsurl=%%%%a" ^& goto texstudionextstep
echo :texstudionextstep
echo del "%%~dp0texstudio.html"
echo for /f tokens^^=4^^ delims^^=^^" %%%%a in ('echo "%%txsurl%%"') do set "txsurl=%%%%a"
echo for /f "tokens=3 delims=-" %%%%a in ('echo "%%txsurl%%"'^) do set "txsver=%%%%a"
echo set /p actualtxsver=^<"%%~dp0texstudio\version.inf"
echo if [%%actualtxsver%%]==[%%txsver%%] goto endupdate
echo curl -L -o texstudio.zip %%txsurl%%
echo mkdir "%%~dp0texstudio-new"
echo tar -xf "%%~dp0texstudio.zip" -C "%%~dp0texstudio-new"
echo del "%%~dp0texstudio.zip"
echo if not exist "%%~dp0texstudio-new\texstudio.exe" set "status=failed" ^& rmdir /s /q "%%~dp0texstudio-new" ^& goto endupdate
echo xcopy /e /i "%%~dp0texstudio\config" "%%~dp0texstudio-new\config"
echo echo %%txsver%%^> "%%~dp0texstudio-new\version.inf"
echo rmdir /s /q "%%~dp0texstudio"
echo rename "%%~dp0texstudio-new" texstudio
echo :endupdate
echo echo.
echo echo -------------------
echo echo Updating %%status%%
echo echo -------------------
echo echo.
echo pause
) > "%~dp0update.bat"

:: uninstall.bat

(
echo @echo off
echo chcp 65001^> nul
echo title Uninstalling TeXfireplace
echo set /p ^< nul = "Press any key to uninstall TeXfireplace . . ."
echo pause ^> nul
echo cls
echo reg delete "HKCU\Software\Classes\.tex" /f
echo reg delete "HKCU\Software\Classes\texfile" /f
echo rmdir /s /q "%%appdata%%\Microsoft\Windows\Start Menu\Programs\TeXfireplace"
echo del "%%userprofile%%\Desktop\TeXstudio.lnk"
echo reg delete "HKCU\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\TeXfireplace" /f
echo cls
echo echo Please wait . . .
echo chdir /d %%localappdata%%
echo rmdir /s /q "%~dp0"
echo cls
echo echo ------------------------
echo echo Uninstallation completed
echo echo ------------------------
echo echo.
echo pause
) > "%~dp0uninstall.bat"

:: Uninstall in registry

curl -L -o texfireplace.ico https://tibortomacs.github.io/texfireplace/source/texfireplace.ico
reg add "HKCU\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\TeXfireplace"
reg add "HKCU\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\TeXfireplace" /v DisplayName /t REG_SZ /d "TeXfireplace"
reg add "HKCU\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\TeXfireplace" /v DisplayIcon /t REG_SZ /d "\"%~dp0texfireplace.ico\""
reg add "HKCU\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\TeXfireplace" /v UninstallString /t REG_SZ /d "\"%~dp0uninstall.bat\""

:: readme.txt

(
echo TeXfireplace components:
echo   - MikTeX (basic version + cm-super + latexmk^)
echo   - TeXstudio
echo   - Strawberry Perl
echo   - Python
echo PATH is written in the texstudio.vbs
) > "%~dp0readme.txt"

:: TeX file association

reg add "HKCU\Software\Classes\.tex" /ve /d "texfile" /f
reg add "HKCU\Software\Classes\texfile\shell\open\command" /ve /d "WScript.exe \"%~dp0texstudio.vbs\" \"%%1\"" /f
reg add "HKCU\Software\Classes\texfile\DefaultIcon" /ve /d "%~dp0texstudio\texstudio.exe,0" /f

:: Shortcuts

(
echo Set WshShell = CreateObject("Wscript.shell"^)
echo Set FSO = CreateObject("Scripting.FileSystemObject"^)
echo Set objFile = FSO.GetFile(Wscript.ScriptFullName^)
echo TeXfireplaceFolder = FSO.GetParentFolderName(objFile^)
echo MiKTeXStartMenuFolder = WshShell.SpecialFolders("StartMenu"^) + "\Programs\TeXfireplace"
echo TeXstudioDesktopLink = WshShell.SpecialFolders("Desktop"^) + "\TeXstudio.lnk"
echo If FSO.FolderExists(MiKTeXStartMenuFolder^) Then FSO.DeleteFolder MiKTeXStartMenuFolder, True
echo If FSO.FileExists(TeXstudioDesktopLink^) Then FSO.DeleteFile TeXstudioDesktopLink, True
echo FSO.CreateFolder(MiKTeXStartMenuFolder^)
echo Set TeXstudioMenuShortcut = WshShell.CreateShortcut(MiKTeXStartMenuFolder + "\TeXstudio.lnk"^)
echo TeXstudioMenuShortcut.TargetPath = TeXfireplaceFolder + "\texstudio.vbs"
echo TeXstudioMenuShortcut.IconLocation = TeXfireplaceFolder + "\texstudio\texstudio.exe"
echo TeXstudioMenuShortcut.WorkingDirectory = TeXfireplaceFolder
echo TeXstudioMenuShortcut.Save
echo Set MiKTeXconsoleMenuShortcut = WshShell.CreateShortcut(MiKTeXStartMenuFolder + "\MiKTeX console.lnk"^)
echo MiKTeXconsoleMenuShortcut.TargetPath = TeXfireplaceFolder + "\miktex-console.vbs"
echo MiKTeXconsoleMenuShortcut.IconLocation = TeXfireplaceFolder + "\texmfs\install\miktex\bin\x64\miktex-console.exe"
echo MiKTeXconsoleMenuShortcut.WorkingDirectory = TeXfireplaceFolder + "\texmfs\install\miktex\bin\x64"
echo MiKTeXconsoleMenuShortcut.Save
echo Set UpdateMenuShortcut = WshShell.CreateShortcut(MiKTeXStartMenuFolder + "\TeXfireplace update.lnk"^)
echo UpdateMenuShortcut.TargetPath = TeXfireplaceFolder + "\update.bat"
echo UpdateMenuShortcut.WorkingDirectory = TeXfireplaceFolder
echo UpdateMenuShortcut.Save
echo Set ReadmeMenuShortcut = WshShell.CreateShortcut(MiKTeXStartMenuFolder + "\Readme.lnk"^)
echo ReadmeMenuShortcut.TargetPath = TeXfireplaceFolder + "\readme.txt"
echo ReadmeMenuShortcut.WorkingDirectory = TeXfireplaceFolder
echo ReadmeMenuShortcut.Save
echo Set TeXstudioDesktopShortcut = WshShell.CreateShortcut(TeXstudioDesktopLink^)
echo TeXstudioDesktopShortcut.TargetPath = TeXfireplaceFolder + "\texstudio.vbs"
echo TeXstudioDesktopShortcut.IconLocation = TeXfireplaceFolder + "\texstudio\texstudio.exe"
echo TeXstudioDesktopShortcut.WorkingDirectory = TeXfireplaceFolder
echo TeXstudioDesktopShortcut.Save
) > "%~dp0makeshortcut.vbs"
cscript /Nologo "%~dp0makeshortcut.vbs"
del "%~dp0makeshortcut.vbs"

cmd /c start /min "" "%~dp0texstudio.vbs"
del "%~dp0postinstall.bat"