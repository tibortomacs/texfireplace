TeXfireplace

Compact framework for using LaTeX:
MiKTeX
Strawberry Perl
Pygments
TeXstudio